//
// Created by Xiuge Chen on 3/23/20.
//

#ifndef TREAPTESTER_UTILS_H
#define TREAPTESTER_UTILS_H

#define likely(x)    __builtin_expect(!!(x), 1)
#define unlikely(x)  __builtin_expect(!!(x), 0)

#endif //TREAPTESTER_UTILS_H
